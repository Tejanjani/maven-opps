package Maven_project.Manasa_Maven.chocolates;

public class Cadbury extends Chocolate {

    public Cadbury(String name,int price,int weight){
        super(name,price,weight);
    }
}
