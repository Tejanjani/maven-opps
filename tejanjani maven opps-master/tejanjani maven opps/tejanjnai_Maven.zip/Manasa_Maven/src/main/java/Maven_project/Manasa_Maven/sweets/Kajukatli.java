package Maven_project.Manasa_Maven.sweets;

public class Kajukatli extends Sweets {

    public Kajukatli(String name, int price, int weight) {
        super(name, price, weight);
    }
}