package Maven_project.Manasa_Maven.sweets;

public class Gulabjamun extends Sweets {

    public Gulabjamun(String name, int price, int weight) {
        super(name, price, weight);
    }
}
