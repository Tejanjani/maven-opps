package Maven_project.Manasa_Maven.sweets;

public class Rasgulla extends Sweets {

    public Rasgulla(String name, int price, int weight) {
        super(name, price, weight);
    }
}